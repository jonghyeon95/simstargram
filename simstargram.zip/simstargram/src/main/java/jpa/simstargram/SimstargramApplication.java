package jpa.simstargram;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimstargramApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimstargramApplication.class, args);
	}

}
