package jpa.simstargram;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimstargramApplicationTests {

	@Test
	void contextLoads() {
	}

}
